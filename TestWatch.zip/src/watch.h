#include <LilyGoWatch.h>

extern TTGOClass *ttgo;

extern bool activeSport;
extern bool lenergy;
extern bool deviceConnected;
extern bool cancelled;